#!/usr/bin/env python3
"""
Fetches live data from the Google Sheet (server-side, so no browser CORS
restriction applies) and rebuilds the MONTHS_DATA / REASONS_DATA constants
embedded in index.html.

Mirrors the exact parsing logic used in the dashboard's own JavaScript
(rebuildMonthFromRows, numPctCol/numRatioCol format detection,
recomputeCheckerAndDead, assignPipelinePR, and the Raw Data reason
aggregation) so results stay consistent whichever side computes them.
"""
import csv
import io
import json
import re
import sys
import urllib.request

SHEET_ID = '1dh5258c6yllkTbTLs6pW_YZOb8sJxh3yOYXmAM4KeGU'
SHEET_GIDS = {'june': '0', 'july': '2133175267', 'august': '1033895553'}
RAW_DATA_GID = '1976096706'
INDEX_HTML_PATH = 'index.html'


def fetch_csv(gid):
    url = f'https://docs.google.com/spreadsheets/d/{SHEET_ID}/gviz/tq?tqx=out:csv&gid={gid}'
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        text = resp.read().decode('utf-8')
    return list(csv.reader(io.StringIO(text)))


def num(v):
    if v is None:
        return 0.0
    v = str(v).strip()
    if v == '':
        return 0.0
    try:
        return float(v.replace('%', '').strip())
    except ValueError:
        return 0.0


def pct_col_detector(rows, pos, col_fn):
    samples = [col_fn(r, pos) for r in rows[:20]]
    has_percent = any('%' in str(s) for s in samples)

    def convert(raw):
        n = num(raw)
        return n if has_percent else n * 100
    return convert


def ratio_col_detector(rows, pos, col_fn):
    samples = [col_fn(r, pos) for r in rows[:20]]
    has_percent = any('%' in str(s) for s in samples)

    def convert(raw):
        n = num(raw)
        return (n / 100) if has_percent else n
    return convert


def rebuild_month_from_rows(rows):
    header_idx = None
    for i, r in enumerate(rows):
        if r and r[0].strip().lower() == 'seller':
            header_idx = i
            break
    if header_idx is None:
        raise ValueError('Could not find header row (expected first column "Seller")')

    header_row = rows[header_idx]
    probe_row = rows[header_idx + 1] if header_idx + 1 < len(rows) else []
    width = max(len(header_row), len(probe_row))
    active_cols = []
    for i in range(width):
        has_header = i < len(header_row) and header_row[i].strip() != ''
        has_probe = i < len(probe_row) and probe_row[i].strip() != ''
        if has_header or has_probe or i == 0:
            active_cols.append(i)

    data_rows = [r for r in rows[header_idx + 1:] if r and r[0].strip() != '']
    if len(data_rows) < 1:
        raise ValueError(f'Parsed too few rows ({len(data_rows)})')

    def col(r, pos):
        idx = active_cols[pos] if pos < len(active_cols) else None
        if idx is None or idx >= len(r):
            return ''
        return r[idx]

    pct_g2n = pct_col_detector(data_rows, 4, col)
    pct_cancel = pct_col_detector(data_rows, 6, col)
    pct_rejmm = pct_col_detector(data_rows, 8, col)
    pct_rejlm = pct_col_detector(data_rows, 10, col)
    pct_returns = pct_col_detector(data_rows, 12, col)
    pct_totaldead = pct_col_detector(data_rows, 14, col)
    pct_pr = pct_col_detector(data_rows, 18, col)
    pct_checker = pct_col_detector(data_rows, 19, col)
    ratio_pipe = ratio_col_detector(data_rows, 16, col)

    records = []
    for r in data_rows:
        records.append({
            'seller': col(r, 0).strip(),
            'module': col(r, 1).strip(),
            'category': col(r, 2).strip() or 'Uncategorized',
            'g2nAbs': num(col(r, 3)), 'g2nPct': pct_g2n(col(r, 4)),
            'cancelAbs': num(col(r, 5)), 'cancelPct': pct_cancel(col(r, 6)),
            'rejectMMAbs': num(col(r, 7)), 'rejectMMPct': pct_rejmm(col(r, 8)),
            'rejectLMAbs': num(col(r, 9)), 'rejectLMPct': pct_rejlm(col(r, 10)),
            'returnsAbs': num(col(r, 11)), 'returnsPct': pct_returns(col(r, 12)),
            'totalDeadAbs': num(col(r, 13)), 'totalDeadPct': pct_totaldead(col(r, 14)),
            'pipeAbs': num(col(r, 15)), 'pipeRatio': ratio_pipe(col(r, 16)),
            'total': num(col(r, 17)),
            'prFromTotal': pct_pr(col(r, 18)),
            'checker': pct_checker(col(r, 19)),
            'legacy': False,
        })
    return records


def assign_pipeline_pr(sellers):
    total_pipeline = sum(s['pipeAbs'] for s in sellers)
    for s in sellers:
        s['pipelinePR'] = (s['pipeAbs'] / total_pipeline * 100) if total_pipeline > 0 else 0
    return sellers


def recompute_checker_and_dead(sellers):
    for s in sellers:
        s['checker'] = (s['g2nPct'] + s['cancelPct'] + s['rejectMMPct'] + s['rejectLMPct']
                         + (s['returnsPct'] or 0) + (s['pipeRatio'] or 0) * 100)
        s['totalDeadPct'] = s['cancelPct'] + s['rejectMMPct'] + s['rejectLMPct']
    return sellers


def fetch_reasons():
    """Raw Data tab: order-level MM/LM rejection reason codes.
    Column positions (0-indexed) confirmed against the sheet:
    C=workshop(2, seller key), F=status(5), G=Reason(6), K=Month(10),
    N=Status Mapping(13), AE=RJ MM Reason(30).
    """
    rows = fetch_csv(RAW_DATA_GID)
    mm, lm = {}, {}
    for r in rows[1:]:
        if len(r) <= 30:
            continue
        seller = (r[2] or '').strip()
        try:
            month_num = int(r[10])
        except (ValueError, IndexError):
            continue
        if not seller or month_num not in (6, 7, 8, 9):
            continue

        mm_reason = (r[30] or '').strip()
        if mm_reason and mm_reason != '-':
            mm.setdefault(seller, {}).setdefault(str(month_num), {})
            mm[seller][str(month_num)][mm_reason] = mm[seller][str(month_num)].get(mm_reason, 0) + 1

        status = (r[5] or '').strip()
        reason = (r[6] or '').strip()
        status_mapping = (r[13] or '').strip()
        if status in ('Attempt', 'Reject', 'Fail') and reason and reason != '#N/A' and status_mapping != 'DELIVERED':
            lm.setdefault(seller, {}).setdefault(str(month_num), {})
            lm[seller][str(month_num)][reason] = lm[seller][str(month_num)].get(reason, 0) + 1

    return {'mm': mm, 'lm': lm}


def main():
    months_data = {}
    for month_key, gid in SHEET_GIDS.items():
        print(f'Fetching {month_key} (gid={gid})...', file=sys.stderr)
        rows = fetch_csv(gid)
        sellers = rebuild_month_from_rows(rows)
        sellers = assign_pipeline_pr(sellers)
        sellers = recompute_checker_and_dead(sellers)
        months_data[month_key] = sellers
        print(f'  {len(sellers)} sellers', file=sys.stderr)

    print('Fetching Raw Data reasons...', file=sys.stderr)
    reasons_data = fetch_reasons()
    print(f'  MM: {len(reasons_data["mm"])} sellers, LM: {len(reasons_data["lm"])} sellers', file=sys.stderr)

    with open(INDEX_HTML_PATH, 'r', encoding='utf-8') as f:
        html = f.read()

    months_json = json.dumps(months_data)
    reasons_json = json.dumps(reasons_data)

    new_html, n1 = re.subn(
        r'const MONTHS_DATA = \{.*?\};',
        'const MONTHS_DATA = ' + months_json.replace('\\', '\\\\') + ';',
        html, count=1, flags=re.S
    )
    if n1 != 1:
        raise RuntimeError('Failed to find/replace MONTHS_DATA in index.html')

    new_html, n2 = re.subn(
        r'const REASONS_DATA = \{.*?\};',
        'const REASONS_DATA = ' + reasons_json.replace('\\', '\\\\') + ';',
        new_html, count=1, flags=re.S
    )
    if n2 != 1:
        raise RuntimeError('Failed to find/replace REASONS_DATA in index.html')

    with open(INDEX_HTML_PATH, 'w', encoding='utf-8') as f:
        f.write(new_html)

    print('index.html updated successfully.', file=sys.stderr)


if __name__ == '__main__':
    main()
